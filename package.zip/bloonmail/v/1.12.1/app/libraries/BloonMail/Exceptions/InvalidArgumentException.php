<?php

namespace BloonMail\Exceptions;

/**
 * @category BloonMail
 * @package Exceptions
 */
class InvalidArgumentException extends Exception {}
