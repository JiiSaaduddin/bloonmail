<?php

namespace BloonMail\Exceptions;

/**
 * @category BloonMail
 * @package Exceptions
 */
class RuntimeException extends Exception {}
