<?php

namespace BloonMail\Exceptions;

class Exception extends \Exception {}
