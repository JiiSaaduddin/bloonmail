<?php

namespace BloonMail\Providers\Filters\Enumerations;

class ConditionField
{
	const FROM = 'From';
	const RECIPIENT = 'Recipient';
	const SUBJECT = 'Subject';
	const HEADER = 'Header';
	const SIZE = 'Size';
}
