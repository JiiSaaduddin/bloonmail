<?php

namespace BloonMail\Providers\Domain;

interface DomainInterface
{
}