<?php

namespace BloonMail\Providers\Filters\Enumerations;

class ConditionsType
{
	const ALL = 'All';
	const ANY = 'Any';
}
