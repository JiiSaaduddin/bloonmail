<?php

namespace BloonMail;

class Account {}
