<?php

namespace BloonMail\Enumerations;

class TimeFormat
{
	const F12 = '12';
	const F24 = '24';
}